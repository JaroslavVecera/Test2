%% Aritmeticke operace 
% obrazky jsou matice, aritmeticke operace s nimi

% nacteni obrazku a vztvoreni druheho
I = imread('picture1.png');
I2 = bitand(I,254); %odstraneni informace y nejmene vyznamneho bitu

figure
subplot(1,2,1)
imshow(I)
title('Original')
subplot(1,2,2)
imshow(I2)
title('Upraveny')

%% Rozdil 2 obrazku
d = I-I2;
figure, imshow(d,[]);

%% naseobeni obrazku - matici, predstavujici vyber oblasti zajmu ROI

I = rgb2gray(imread('coins2.png'));
ROI = uint8(zeros(243,296));
ROI(143:200,205:260) = 1;
ROI(19:75,23:83) = 1;

p = I.*ROI;

figure
subplot(1,3,1)
imshow(I)
title('Original')
subplot(1,3,2)
imshow(ROI,[])
title('ROI')
subplot(1,3,3)
imshow(p)
title('Vysledek')

%% Logick� operace and, or, xor, not
%vytvoreni 2 obrazku 

A = logical(zeros(500));
B = logical(zeros(500));

A(50:300, 50:300) = 1;
B(150:450, 150:450) = 1;

%% and
figure
subplot(1,3,1)
imshow(A)
title('A')
subplot(1,3,2)
imshow(B)
title('B')
subplot(1,3,3)
imshow(and(A,B))
title('and')

%% or
figure
subplot(1,3,1)
imshow(A)
title('A')
subplot(1,3,2)
imshow(B)
title('B')
subplot(1,3,3)
imshow(or(A,B))
title('or')

%% xor
figure
subplot(1,3,1)
imshow(A)
title('A')
subplot(1,3,2)
imshow(B)
title('B')
subplot(1,3,3)
imshow(xor(A,B))
title('xor')

%% not
figure
subplot(1,2,1)
imshow(A)
title('A')
subplot(1,2,2)
imshow(not(A))
title('not')

%% geometricke transformace

% tform = maketform(typ, parametry, ...)
% typ : 'affine', 'projective', 'custom', 'box', 'composite'

%'custom' pro uzivatelsky definovane transformacni funkce
% tform = maketform('custom', ndim_in, ndim_out, dopredna_fce, zpetna_fce, data)

%Priklad:
% (x,y) = T{(w,z)} = (3w,2z)
% (w,z) = T^(-1){(x,y)} = (x/3, y/2)

% dopredna_fce
dopredna_fce = @(wz,tdata) [3*wz(:,1),2*wz(:,2)]

% zpetna_fce
zpetna_fce = @(xy,tdata) [xy(:,1)/3,xy(:,2)/2]

% transformacni struktura 
tform1 = maketform('custom',2,2,dopredna_fce, zpetna_fce,[])

%% aplikace transformace
% XY = tformfwd(WZ,tform)
% WZ = tforminv(XY,tform)

WZ = [1 1; 3 2];
XY = tformfwd(WZ,tform1)

WZ2 = tforminv(XY,tform1)

%% Priklad 1
% vytvorte transformacni strukturu pro funkce
% (x,y) = T{(w,z)} = (w+0.4z,z)
% (w,z) = T^(-1){(x,y)} = (x-0.4y, y)
% vyzkousejte na WZ  = [1 1; 3 2] 
% tform2


%% Vizualizace

vistform(tform1,pointgrid([0 0; 100 100]));
%figure, vistform(tform2,pointgrid([0 0; 100 100]));

%% Afinni transformace
% pomoci maketform('affine',T)
% nebo 
% tform = affine2d(T)

%afinni transformace odpovidajici tform1
T1 = [3 0 0; 0 2 0; 0 0 1];

tform3 = maketform('affine',T1);
WZ = [1 1; 3 2];
XY = tformfwd(WZ,tform3)

WZ2 = tforminv(XY,tform3)

%% Prikald 2
% Jak vypada afinni matice odpovidajici tform2

%T2 = ..... doplnte
% tform4 = maketform('affine',T2);

% porovnejte s vysledky pro tform2
% WZ = [1 1; 3 2];
% XY = tformfwd(WZ,tform4)
% WZ2 = tforminv(XY,tform4)

%% Vizualizace otoceni
uhel = pi/3;
T = [cos(uhel) sin(uhel) 0; -sin(uhel) cos(uhel) 0; 0 0 1];
tform5 = maketform('affine',T);

vistform(tform5,pointgrid([0 0; 100 100]));

%% aplikace na obrazky
% g = imtransform(f,tform);
% nebo
% g = imwarp(f,tform);

f = imread('picture1.png');

g1 = imtransform(f,tform1);
%g2 = imtransform(f,tform2);
%g3 = imtransform(f,tform3);
%g4 = imtransform(f,tform4);
g5 = imtransform(f,tform5);

imshow(g1);
axis on;
%figure, imshow(g2);

%% Matlab transformace
%imtranslate, imrotate

T = imread('t.png');
T2 = imtranslate(T, [50,50]);

figure
subplot(1,2,1)
imshow(T)
title('original')
subplot(1,2,2)
imshow(T2)
title('posunuti')

%%
T2 = imrotate(T, 30);

figure
subplot(1,2,1)
imshow(T)
title('original')
subplot(1,2,2)
imshow(T2)
title('otoceni')



%% Interpolace
g5a = imtransform(f(300:500,300:500),tform5, 'nearest');
g5b = imtransform(f(300:500,300:500),tform5, 'bilinear');
g5c = imtransform(f(300:500,300:500),tform5, 'bicubic');

subplot(1,3,1), imshow(g5a);
subplot(1,3,2), imshow(g5b);
subplot(1,3,3), imshow(g5c);

%% Registrace
% Nacteni obrazku a vytvoreni noveho pomoci afinni trnasformace

T = imread('t.png');
tform = affine2d([1 0 0; -0.5 1 0; 0 0 1]);

T2 = imwarp(T,tform);

figure
subplot(1,2,1)
imshow(T)
subplot(1,2,2)
imshow(T2)

%% vyber kontrolnich bodu
cpselect(T,T2);

%% hledani transformace
tform2 = fitgeotrans(movingPoints,fixedPoints,'affine')

%% Aplikace nalezene transformace
T3 = imwarp(T,tform2);
figure
subplot(1,2,1)
imshow(T2)
subplot(1,2,2)
imshow(T3)

%% Priklad 3
% Naprogramujte funkci registrace, kter� jako vstup bere 2 obr�zky, kter� obsahuj� �ern� obd�ln�k (obdelnik1.png a obdelnik2.png) . 
% P�edpokl�dejme, �e obd�ln�ky na obou obr�zc�ch jsou ty sam�, jen druh� obd�ln�k je posunut� a deformovan� operac� zv�t�en�/zmen�en�
% v os�ch x a y. Funkce vrac� 3 hodnoty � vektor posunut� a 2 koeficienty p�edstavuj�c� m�ru zv�t�en�/zmen�en� v ose x a v ose y.

% Pro nasledujici matice by byl vystup posunuti = [2,1], zvetseni_x = 1.5,
% zvetseni_y = 2

M1 = [ 1 1 1 1 1 1;
            1 0 0 1 1 1;
            1 0 0 1 1 1;
            1 1 1 1 1 1;
            1 1 1 1 1 1;
            1 1 1 1 1 1];
        
M2 = [ 1 1 1 1 1 1;
            1 1 1 1 1 1;
            1 1 1 1 1 1;
            1 1 1 0 0 0;
            1 1 1 0 0 0;
            1 1 1 0 0 0];


%% Morfovani obrazku

I = rgb2gray(imread('morf1.jpg'));
J = rgb2gray(imread('morf2.jpg'));
M = morph(I,J,10);

for i=1:10
    subplot(2,5,i), imshow(M(:,:,i),[]);
end

